﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;
using System.IO;


namespace HMIProject
{
    public class GVariable
    {
        public string name;
        public string dataType;
        public string initialValue;
        public string ipAddress;
        public string port;
        [XmlAttribute]
        public string type;
    }
}
