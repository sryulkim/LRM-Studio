/****************************************************************************
** Meta object code from reading C++ file 'hmiform.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../hmiform.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'hmiform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_HMIForm_t {
    QByteArrayData data[135];
    char stringdata0[2796];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_HMIForm_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_HMIForm_t qt_meta_stringdata_HMIForm = {
    {
QT_MOC_LITERAL(0, 0, 7), // "HMIForm"
QT_MOC_LITERAL(1, 8, 7), // "ClassID"
QT_MOC_LITERAL(2, 16, 38), // "{4B46A2D5-65A9-40DD-9EC2-5D7D..."
QT_MOC_LITERAL(3, 55, 11), // "InterfaceID"
QT_MOC_LITERAL(4, 67, 38), // "{0779FBA0-96AB-4A31-8A58-7C0D..."
QT_MOC_LITERAL(5, 106, 8), // "EventsID"
QT_MOC_LITERAL(6, 115, 38), // "{36115845-A13F-47E5-9D73-0568..."
QT_MOC_LITERAL(7, 154, 12), // "ToSuperClass"
QT_MOC_LITERAL(8, 167, 11), // "StockEvents"
QT_MOC_LITERAL(9, 179, 3), // "yes"
QT_MOC_LITERAL(10, 183, 10), // "Insertable"
QT_MOC_LITERAL(11, 194, 18), // "radioButtonClicked"
QT_MOC_LITERAL(12, 213, 0), // ""
QT_MOC_LITERAL(13, 214, 16), // "selectedGUIOName"
QT_MOC_LITERAL(14, 231, 8), // "GUIOName"
QT_MOC_LITERAL(15, 240, 8), // "GUIOType"
QT_MOC_LITERAL(16, 249, 9), // "GUIOLayer"
QT_MOC_LITERAL(17, 259, 15), // "MakeGUIOCommand"
QT_MOC_LITERAL(18, 275, 17), // "RemoveGUIOCommand"
QT_MOC_LITERAL(19, 293, 12), // "EditPageName"
QT_MOC_LITERAL(20, 306, 27), // "EditPageBackgroundImageName"
QT_MOC_LITERAL(21, 334, 23), // "EditPageBackgroundColor"
QT_MOC_LITERAL(22, 358, 20), // "EditGUIOPropertyName"
QT_MOC_LITERAL(23, 379, 21), // "EditGUIOPropertyLayer"
QT_MOC_LITERAL(24, 401, 17), // "EditGUIOPropertyX"
QT_MOC_LITERAL(25, 419, 17), // "EditGUIOPropertyY"
QT_MOC_LITERAL(26, 437, 21), // "EditGUIOPropertyWidth"
QT_MOC_LITERAL(27, 459, 22), // "EditGUIOPropertyHeight"
QT_MOC_LITERAL(28, 482, 18), // "EditPushButtonText"
QT_MOC_LITERAL(29, 501, 19), // "EditPushButtonColor"
QT_MOC_LITERAL(30, 521, 23), // "EditPushButtonThickness"
QT_MOC_LITERAL(31, 545, 25), // "EditPushButtonBorderColor"
QT_MOC_LITERAL(32, 571, 23), // "EditPushButtonFontColor"
QT_MOC_LITERAL(33, 595, 22), // "EditPushButtonFontSize"
QT_MOC_LITERAL(34, 618, 22), // "EditPushButtonFontBold"
QT_MOC_LITERAL(35, 641, 27), // "EditPushButtonFontUnderline"
QT_MOC_LITERAL(36, 669, 13), // "EditDialColor"
QT_MOC_LITERAL(37, 683, 19), // "EditDialNeedleColor"
QT_MOC_LITERAL(38, 703, 17), // "EditDialFontColor"
QT_MOC_LITERAL(39, 721, 11), // "EditDialMin"
QT_MOC_LITERAL(40, 733, 11), // "EditDialMax"
QT_MOC_LITERAL(41, 745, 13), // "EditDialMinor"
QT_MOC_LITERAL(42, 759, 13), // "EditDialMajor"
QT_MOC_LITERAL(43, 773, 20), // "EditProgressBarColor"
QT_MOC_LITERAL(44, 794, 21), // "EditProgressBarOrient"
QT_MOC_LITERAL(45, 816, 18), // "EditProgressBarMin"
QT_MOC_LITERAL(46, 835, 18), // "EditProgressBarMax"
QT_MOC_LITERAL(47, 854, 20), // "EditProgressBarMinor"
QT_MOC_LITERAL(48, 875, 20), // "EditProgressBarMajor"
QT_MOC_LITERAL(49, 896, 18), // "EditSliderBarColor"
QT_MOC_LITERAL(50, 915, 24), // "EditSliderBarHandleColor"
QT_MOC_LITERAL(51, 940, 19), // "EditSliderBarOrient"
QT_MOC_LITERAL(52, 960, 16), // "EditSliderBarMin"
QT_MOC_LITERAL(53, 977, 16), // "EditSliderBarMax"
QT_MOC_LITERAL(54, 994, 18), // "EditSliderBarMinor"
QT_MOC_LITERAL(55, 1013, 18), // "EditSliderBarMajor"
QT_MOC_LITERAL(56, 1032, 25), // "EditNumPadNumberFontColor"
QT_MOC_LITERAL(57, 1058, 27), // "EditNumPadNumberButtonColor"
QT_MOC_LITERAL(58, 1086, 24), // "EditNumPadResetFontColor"
QT_MOC_LITERAL(59, 1111, 26), // "EditNumPadResetButtonColor"
QT_MOC_LITERAL(60, 1138, 21), // "EditNumPadOkFontColor"
QT_MOC_LITERAL(61, 1160, 23), // "EditNumPadOkButtonColor"
QT_MOC_LITERAL(62, 1184, 21), // "EditNumPadBorderColor"
QT_MOC_LITERAL(63, 1206, 20), // "EditLoginPadPassword"
QT_MOC_LITERAL(64, 1227, 27), // "EditLoginPadNumberFontColor"
QT_MOC_LITERAL(65, 1255, 29), // "EditLoginPadNumberButtonColor"
QT_MOC_LITERAL(66, 1285, 26), // "EditLoginPadResetFontColor"
QT_MOC_LITERAL(67, 1312, 28), // "EditLoginPadResetButtonColor"
QT_MOC_LITERAL(68, 1341, 26), // "EditLoginPadLoginFontColor"
QT_MOC_LITERAL(69, 1368, 28), // "EditLoginPadLoginButtonColor"
QT_MOC_LITERAL(70, 1397, 25), // "EditLoginPadFuncFontColor"
QT_MOC_LITERAL(71, 1423, 27), // "EditLoginPadFuncButtonColor"
QT_MOC_LITERAL(72, 1451, 23), // "EditLoginPadBorderColor"
QT_MOC_LITERAL(73, 1475, 23), // "EditLoginPadDigitNumber"
QT_MOC_LITERAL(74, 1499, 14), // "EditLabelColor"
QT_MOC_LITERAL(75, 1514, 20), // "EditLabelBorderColor"
QT_MOC_LITERAL(76, 1535, 18), // "EditLabelFontColor"
QT_MOC_LITERAL(77, 1554, 17), // "EditLabelFontSize"
QT_MOC_LITERAL(78, 1572, 17), // "EditLabelFontBold"
QT_MOC_LITERAL(79, 1590, 22), // "EditLabelFontUnderline"
QT_MOC_LITERAL(80, 1613, 18), // "EditLabelAlignment"
QT_MOC_LITERAL(81, 1632, 18), // "EditLabelThickness"
QT_MOC_LITERAL(82, 1651, 14), // "EditLabelAngle"
QT_MOC_LITERAL(83, 1666, 13), // "EditLabelText"
QT_MOC_LITERAL(84, 1680, 20), // "EditLabelTransparent"
QT_MOC_LITERAL(85, 1701, 16), // "EditLabelVisible"
QT_MOC_LITERAL(86, 1718, 20), // "EditScrollLabelColor"
QT_MOC_LITERAL(87, 1739, 26), // "EditScrollLabelBorderColor"
QT_MOC_LITERAL(88, 1766, 24), // "EditScrollLabelFontColor"
QT_MOC_LITERAL(89, 1791, 23), // "EditScrollLabelFontSize"
QT_MOC_LITERAL(90, 1815, 23), // "EditScrollLabelFontBold"
QT_MOC_LITERAL(91, 1839, 28), // "EditScrollLabelFontUnderline"
QT_MOC_LITERAL(92, 1868, 24), // "EditScrollLabelThickness"
QT_MOC_LITERAL(93, 1893, 19), // "EditScrollLabelText"
QT_MOC_LITERAL(94, 1913, 26), // "EditScrollLabelTransparent"
QT_MOC_LITERAL(95, 1940, 24), // "EditScrollLabelDirection"
QT_MOC_LITERAL(96, 1965, 20), // "EditScrollLabelSpeed"
QT_MOC_LITERAL(97, 1986, 22), // "EditScrollLabelVisible"
QT_MOC_LITERAL(98, 2009, 25), // "EditScrollLabelScrollFlag"
QT_MOC_LITERAL(99, 2035, 21), // "EditDigitalClockColor"
QT_MOC_LITERAL(100, 2057, 27), // "EditDigitalClockBorderColor"
QT_MOC_LITERAL(101, 2085, 25), // "EditDigitalClockFontColor"
QT_MOC_LITERAL(102, 2111, 24), // "EditDigitalClockFontBold"
QT_MOC_LITERAL(103, 2136, 24), // "EditDigitalClockFontSize"
QT_MOC_LITERAL(104, 2161, 27), // "EditDigitalClockTransparent"
QT_MOC_LITERAL(105, 2189, 12), // "EditLedColor"
QT_MOC_LITERAL(106, 2202, 12), // "EditPanelMax"
QT_MOC_LITERAL(107, 2215, 12), // "EditPanelMin"
QT_MOC_LITERAL(108, 2228, 14), // "EditPanelMajor"
QT_MOC_LITERAL(109, 2243, 14), // "EditPanelMinor"
QT_MOC_LITERAL(110, 2258, 20), // "EditPanelNeedleColor"
QT_MOC_LITERAL(111, 2279, 19), // "EditPanelDigitColor"
QT_MOC_LITERAL(112, 2299, 18), // "EditPanelBodyColor"
QT_MOC_LITERAL(113, 2318, 13), // "EditImageName"
QT_MOC_LITERAL(114, 2332, 18), // "EditImageGrayScale"
QT_MOC_LITERAL(115, 2351, 14), // "EditImageAngle"
QT_MOC_LITERAL(116, 2366, 16), // "EditImageVisible"
QT_MOC_LITERAL(117, 2383, 17), // "EditRailImageName"
QT_MOC_LITERAL(118, 2401, 17), // "EditRailGrayScale"
QT_MOC_LITERAL(119, 2419, 19), // "EditCircleFillColor"
QT_MOC_LITERAL(120, 2439, 19), // "EditCircleLineColor"
QT_MOC_LITERAL(121, 2459, 23), // "EditCircleLineThickness"
QT_MOC_LITERAL(122, 2483, 22), // "EditRectangleFillColor"
QT_MOC_LITERAL(123, 2506, 22), // "EditRectangleLineColor"
QT_MOC_LITERAL(124, 2529, 26), // "EditRectangleLineThickness"
QT_MOC_LITERAL(125, 2556, 17), // "EditRadioButtonID"
QT_MOC_LITERAL(126, 2574, 19), // "EditRadioButtonText"
QT_MOC_LITERAL(127, 2594, 20), // "EditRadioButtonColor"
QT_MOC_LITERAL(128, 2615, 24), // "EditRadioButtonThickness"
QT_MOC_LITERAL(129, 2640, 26), // "EditRadioButtonBorderColor"
QT_MOC_LITERAL(130, 2667, 24), // "EditRadioButtonFontColor"
QT_MOC_LITERAL(131, 2692, 23), // "EditRadioButtonFontSize"
QT_MOC_LITERAL(132, 2716, 23), // "EditRadioButtonFontBold"
QT_MOC_LITERAL(133, 2740, 28), // "EditRadioButtonFontUnderline"
QT_MOC_LITERAL(134, 2769, 26) // "EditRadioButtonTransparent"

    },
    "HMIForm\0ClassID\0{4B46A2D5-65A9-40DD-9EC2-5D7D11072B93}\0"
    "InterfaceID\0{0779FBA0-96AB-4A31-8A58-7C0DB7A832E9}\0"
    "EventsID\0{36115845-A13F-47E5-9D73-056841C82847}\0"
    "ToSuperClass\0StockEvents\0yes\0Insertable\0"
    "radioButtonClicked\0\0selectedGUIOName\0"
    "GUIOName\0GUIOType\0GUIOLayer\0MakeGUIOCommand\0"
    "RemoveGUIOCommand\0EditPageName\0"
    "EditPageBackgroundImageName\0"
    "EditPageBackgroundColor\0EditGUIOPropertyName\0"
    "EditGUIOPropertyLayer\0EditGUIOPropertyX\0"
    "EditGUIOPropertyY\0EditGUIOPropertyWidth\0"
    "EditGUIOPropertyHeight\0EditPushButtonText\0"
    "EditPushButtonColor\0EditPushButtonThickness\0"
    "EditPushButtonBorderColor\0"
    "EditPushButtonFontColor\0EditPushButtonFontSize\0"
    "EditPushButtonFontBold\0"
    "EditPushButtonFontUnderline\0EditDialColor\0"
    "EditDialNeedleColor\0EditDialFontColor\0"
    "EditDialMin\0EditDialMax\0EditDialMinor\0"
    "EditDialMajor\0EditProgressBarColor\0"
    "EditProgressBarOrient\0EditProgressBarMin\0"
    "EditProgressBarMax\0EditProgressBarMinor\0"
    "EditProgressBarMajor\0EditSliderBarColor\0"
    "EditSliderBarHandleColor\0EditSliderBarOrient\0"
    "EditSliderBarMin\0EditSliderBarMax\0"
    "EditSliderBarMinor\0EditSliderBarMajor\0"
    "EditNumPadNumberFontColor\0"
    "EditNumPadNumberButtonColor\0"
    "EditNumPadResetFontColor\0"
    "EditNumPadResetButtonColor\0"
    "EditNumPadOkFontColor\0EditNumPadOkButtonColor\0"
    "EditNumPadBorderColor\0EditLoginPadPassword\0"
    "EditLoginPadNumberFontColor\0"
    "EditLoginPadNumberButtonColor\0"
    "EditLoginPadResetFontColor\0"
    "EditLoginPadResetButtonColor\0"
    "EditLoginPadLoginFontColor\0"
    "EditLoginPadLoginButtonColor\0"
    "EditLoginPadFuncFontColor\0"
    "EditLoginPadFuncButtonColor\0"
    "EditLoginPadBorderColor\0EditLoginPadDigitNumber\0"
    "EditLabelColor\0EditLabelBorderColor\0"
    "EditLabelFontColor\0EditLabelFontSize\0"
    "EditLabelFontBold\0EditLabelFontUnderline\0"
    "EditLabelAlignment\0EditLabelThickness\0"
    "EditLabelAngle\0EditLabelText\0"
    "EditLabelTransparent\0EditLabelVisible\0"
    "EditScrollLabelColor\0EditScrollLabelBorderColor\0"
    "EditScrollLabelFontColor\0"
    "EditScrollLabelFontSize\0EditScrollLabelFontBold\0"
    "EditScrollLabelFontUnderline\0"
    "EditScrollLabelThickness\0EditScrollLabelText\0"
    "EditScrollLabelTransparent\0"
    "EditScrollLabelDirection\0EditScrollLabelSpeed\0"
    "EditScrollLabelVisible\0EditScrollLabelScrollFlag\0"
    "EditDigitalClockColor\0EditDigitalClockBorderColor\0"
    "EditDigitalClockFontColor\0"
    "EditDigitalClockFontBold\0"
    "EditDigitalClockFontSize\0"
    "EditDigitalClockTransparent\0EditLedColor\0"
    "EditPanelMax\0EditPanelMin\0EditPanelMajor\0"
    "EditPanelMinor\0EditPanelNeedleColor\0"
    "EditPanelDigitColor\0EditPanelBodyColor\0"
    "EditImageName\0EditImageGrayScale\0"
    "EditImageAngle\0EditImageVisible\0"
    "EditRailImageName\0EditRailGrayScale\0"
    "EditCircleFillColor\0EditCircleLineColor\0"
    "EditCircleLineThickness\0EditRectangleFillColor\0"
    "EditRectangleLineColor\0"
    "EditRectangleLineThickness\0EditRadioButtonID\0"
    "EditRadioButtonText\0EditRadioButtonColor\0"
    "EditRadioButtonThickness\0"
    "EditRadioButtonBorderColor\0"
    "EditRadioButtonFontColor\0"
    "EditRadioButtonFontSize\0EditRadioButtonFontBold\0"
    "EditRadioButtonFontUnderline\0"
    "EditRadioButtonTransparent"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_HMIForm[] = {

 // content:
       7,       // revision
       0,       // classname
       6,   14, // classinfo
       1,   26, // methods
     122,   32, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // classinfo: key, value
       1,    2,
       3,    4,
       5,    6,
       7,    0,
       8,    9,
      10,    9,

 // slots: name, argc, parameters, tag, flags
      11,    0,   31,   12, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

 // properties: name, type, flags
      13, QMetaType::QString, 0x00095103,
      14, QMetaType::QString, 0x00095103,
      15, QMetaType::QString, 0x00095103,
      16, QMetaType::Int, 0x00095103,
      17, QMetaType::Bool, 0x00095103,
      18, QMetaType::Bool, 0x00095103,
      19, QMetaType::QString, 0x00095103,
      20, QMetaType::QString, 0x00095103,
      21, QMetaType::Int, 0x00095103,
      22, QMetaType::QString, 0x00095103,
      23, QMetaType::Int, 0x00095103,
      24, QMetaType::Int, 0x00095103,
      25, QMetaType::Int, 0x00095103,
      26, QMetaType::Int, 0x00095103,
      27, QMetaType::Int, 0x00095103,
      28, QMetaType::QString, 0x00095103,
      29, QMetaType::Int, 0x00095103,
      30, QMetaType::Int, 0x00095103,
      31, QMetaType::Int, 0x00095103,
      32, QMetaType::Int, 0x00095103,
      33, QMetaType::Int, 0x00095103,
      34, QMetaType::Bool, 0x00095103,
      35, QMetaType::Bool, 0x00095103,
      36, QMetaType::Int, 0x00095103,
      37, QMetaType::Int, 0x00095103,
      38, QMetaType::Int, 0x00095103,
      39, QMetaType::Int, 0x00095103,
      40, QMetaType::Int, 0x00095103,
      41, QMetaType::Int, 0x00095103,
      42, QMetaType::Int, 0x00095103,
      43, QMetaType::Int, 0x00095103,
      44, QMetaType::Int, 0x00095103,
      45, QMetaType::Int, 0x00095103,
      46, QMetaType::Int, 0x00095103,
      47, QMetaType::Int, 0x00095103,
      48, QMetaType::Int, 0x00095103,
      49, QMetaType::Int, 0x00095103,
      50, QMetaType::Int, 0x00095103,
      51, QMetaType::Int, 0x00095103,
      52, QMetaType::Int, 0x00095103,
      53, QMetaType::Int, 0x00095103,
      54, QMetaType::Int, 0x00095103,
      55, QMetaType::Int, 0x00095103,
      56, QMetaType::Int, 0x00095103,
      57, QMetaType::Int, 0x00095103,
      58, QMetaType::Int, 0x00095103,
      59, QMetaType::Int, 0x00095103,
      60, QMetaType::Int, 0x00095103,
      61, QMetaType::Int, 0x00095103,
      62, QMetaType::Int, 0x00095103,
      63, QMetaType::QString, 0x00095103,
      64, QMetaType::Int, 0x00095103,
      65, QMetaType::Int, 0x00095103,
      66, QMetaType::Int, 0x00095103,
      67, QMetaType::Int, 0x00095103,
      68, QMetaType::Int, 0x00095103,
      69, QMetaType::Int, 0x00095103,
      70, QMetaType::Int, 0x00095103,
      71, QMetaType::Int, 0x00095003,
      72, QMetaType::Int, 0x00095103,
      73, QMetaType::Int, 0x00095103,
      74, QMetaType::Int, 0x00095103,
      75, QMetaType::Int, 0x00095103,
      76, QMetaType::Int, 0x00095103,
      77, QMetaType::Int, 0x00095103,
      78, QMetaType::Bool, 0x00095103,
      79, QMetaType::Bool, 0x00095103,
      80, QMetaType::Int, 0x00095103,
      81, QMetaType::Int, 0x00095103,
      82, QMetaType::Int, 0x00095103,
      83, QMetaType::QString, 0x00095103,
      84, QMetaType::Bool, 0x00095103,
      85, QMetaType::Int, 0x00095103,
      86, QMetaType::Int, 0x00095103,
      87, QMetaType::Int, 0x00095103,
      88, QMetaType::Int, 0x00095103,
      89, QMetaType::Int, 0x00095103,
      90, QMetaType::Bool, 0x00095103,
      91, QMetaType::Bool, 0x00095103,
      92, QMetaType::Int, 0x00095103,
      93, QMetaType::QString, 0x00095103,
      94, QMetaType::Bool, 0x00095103,
      95, QMetaType::Int, 0x00095103,
      96, QMetaType::Int, 0x00095103,
      97, QMetaType::Int, 0x00095103,
      98, QMetaType::Int, 0x00095103,
      99, QMetaType::Int, 0x00095103,
     100, QMetaType::Int, 0x00095103,
     101, QMetaType::Int, 0x00095103,
     102, QMetaType::Int, 0x00095103,
     103, QMetaType::Int, 0x00095103,
     104, QMetaType::Int, 0x00095103,
     105, QMetaType::Int, 0x00095103,
     106, QMetaType::Int, 0x00095103,
     107, QMetaType::Int, 0x00095103,
     108, QMetaType::Int, 0x00095103,
     109, QMetaType::Int, 0x00095103,
     110, QMetaType::Int, 0x00095103,
     111, QMetaType::Int, 0x00095103,
     112, QMetaType::Int, 0x00095103,
     113, QMetaType::QString, 0x00095103,
     114, QMetaType::Bool, 0x00095103,
     115, QMetaType::Int, 0x00095103,
     116, QMetaType::Int, 0x00095103,
     117, QMetaType::QString, 0x00095103,
     118, QMetaType::Bool, 0x00095103,
     119, QMetaType::Int, 0x00095103,
     120, QMetaType::Int, 0x00095103,
     121, QMetaType::Int, 0x00095103,
     122, QMetaType::Int, 0x00095103,
     123, QMetaType::Int, 0x00095103,
     124, QMetaType::Int, 0x00095103,
     125, QMetaType::Int, 0x00095103,
     126, QMetaType::QString, 0x00095103,
     127, QMetaType::Int, 0x00095103,
     128, QMetaType::Int, 0x00095103,
     129, QMetaType::Int, 0x00095103,
     130, QMetaType::Int, 0x00095103,
     131, QMetaType::Int, 0x00095103,
     132, QMetaType::Bool, 0x00095103,
     133, QMetaType::Bool, 0x00095103,
     134, QMetaType::Bool, 0x00095103,

       0        // eod
};

void HMIForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        HMIForm *_t = static_cast<HMIForm *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->radioButtonClicked(); break;
        default: ;
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        HMIForm *_t = static_cast<HMIForm *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->getSelectedGUIOName(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->getGUIOName(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->getGUIOType(); break;
        case 3: *reinterpret_cast< int*>(_v) = _t->getGUIOLayer(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->getMakeGUIOCommand(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->getRemoveGUIOCommand(); break;
        case 6: *reinterpret_cast< QString*>(_v) = _t->getEditPageName(); break;
        case 7: *reinterpret_cast< QString*>(_v) = _t->getEditPageBackgroundImageName(); break;
        case 8: *reinterpret_cast< int*>(_v) = _t->getEditPageBackgroundColor(); break;
        case 9: *reinterpret_cast< QString*>(_v) = _t->getEditGUIOPropertyName(); break;
        case 10: *reinterpret_cast< int*>(_v) = _t->getEditGUIOPropertyLayer(); break;
        case 11: *reinterpret_cast< int*>(_v) = _t->getEditGUIOPropertyX(); break;
        case 12: *reinterpret_cast< int*>(_v) = _t->getEditGUIOPropertyY(); break;
        case 13: *reinterpret_cast< int*>(_v) = _t->getEditGUIOPropertyWidth(); break;
        case 14: *reinterpret_cast< int*>(_v) = _t->getEditGUIOPropertyHeight(); break;
        case 15: *reinterpret_cast< QString*>(_v) = _t->getEditPushButtonText(); break;
        case 16: *reinterpret_cast< int*>(_v) = _t->getEditPushButtonColor(); break;
        case 17: *reinterpret_cast< int*>(_v) = _t->getEditPushButtonThickness(); break;
        case 18: *reinterpret_cast< int*>(_v) = _t->getEditPushButtonBorderColor(); break;
        case 19: *reinterpret_cast< int*>(_v) = _t->getEditPushButtonFontColor(); break;
        case 20: *reinterpret_cast< int*>(_v) = _t->getEditPushButtonFontColor(); break;
        case 21: *reinterpret_cast< bool*>(_v) = _t->getEditPushButtonFontBold(); break;
        case 22: *reinterpret_cast< bool*>(_v) = _t->getEditPushButtonFontUnderline(); break;
        case 23: *reinterpret_cast< int*>(_v) = _t->getEditDialColor(); break;
        case 24: *reinterpret_cast< int*>(_v) = _t->getEditDialNeedleColor(); break;
        case 25: *reinterpret_cast< int*>(_v) = _t->getEditDialFontColor(); break;
        case 26: *reinterpret_cast< int*>(_v) = _t->getEditDialMin(); break;
        case 27: *reinterpret_cast< int*>(_v) = _t->getEditDialMax(); break;
        case 28: *reinterpret_cast< int*>(_v) = _t->getEditDialMinor(); break;
        case 29: *reinterpret_cast< int*>(_v) = _t->getEditDialMajor(); break;
        case 30: *reinterpret_cast< int*>(_v) = _t->getEditProgressBarColor(); break;
        case 31: *reinterpret_cast< int*>(_v) = _t->getEditProgressBarOrient(); break;
        case 32: *reinterpret_cast< int*>(_v) = _t->getEditProgressBarMin(); break;
        case 33: *reinterpret_cast< int*>(_v) = _t->getEditProgressBarMax(); break;
        case 34: *reinterpret_cast< int*>(_v) = _t->getEditProgressBarMinor(); break;
        case 35: *reinterpret_cast< int*>(_v) = _t->getEditProgressBarMajor(); break;
        case 36: *reinterpret_cast< int*>(_v) = _t->getEditSliderBarColor(); break;
        case 37: *reinterpret_cast< int*>(_v) = _t->getEditSliderBarHandleColor(); break;
        case 38: *reinterpret_cast< int*>(_v) = _t->getEditSliderBarOrient(); break;
        case 39: *reinterpret_cast< int*>(_v) = _t->getEditSliderBarMin(); break;
        case 40: *reinterpret_cast< int*>(_v) = _t->getEditSliderBarMax(); break;
        case 41: *reinterpret_cast< int*>(_v) = _t->getEditSliderBarMinor(); break;
        case 42: *reinterpret_cast< int*>(_v) = _t->getEditSliderBarMajor(); break;
        case 43: *reinterpret_cast< int*>(_v) = _t->getEditNumPadNumberFontColor(); break;
        case 44: *reinterpret_cast< int*>(_v) = _t->getEditNumPadNumberButtonColor(); break;
        case 45: *reinterpret_cast< int*>(_v) = _t->getEditNumPadResetFontColor(); break;
        case 46: *reinterpret_cast< int*>(_v) = _t->getEditNumPadResetButtonColor(); break;
        case 47: *reinterpret_cast< int*>(_v) = _t->getEditNumPadOkFontColor(); break;
        case 48: *reinterpret_cast< int*>(_v) = _t->getEditNumPadOkButtonColor(); break;
        case 49: *reinterpret_cast< int*>(_v) = _t->getEditNumPadBorderColor(); break;
        case 50: *reinterpret_cast< QString*>(_v) = _t->getEditLoginPadPassword(); break;
        case 51: *reinterpret_cast< int*>(_v) = _t->getEditLoginPadNumberFontColor(); break;
        case 52: *reinterpret_cast< int*>(_v) = _t->getEditLoginPadNumberButtonColor(); break;
        case 53: *reinterpret_cast< int*>(_v) = _t->getEditLoginPadResetFontColor(); break;
        case 54: *reinterpret_cast< int*>(_v) = _t->getEditLoginPadResetButtonColor(); break;
        case 55: *reinterpret_cast< int*>(_v) = _t->getEditLoginPadLoginFontColor(); break;
        case 56: *reinterpret_cast< int*>(_v) = _t->getEditLoginPadLoginButtonColor(); break;
        case 57: *reinterpret_cast< int*>(_v) = _t->getEditLoginPadFuncFontColor(); break;
        case 58: *reinterpret_cast< int*>(_v) = _t->getEditLoginPadFuncButtonColor(); break;
        case 59: *reinterpret_cast< int*>(_v) = _t->getEditLoginPadBorderColor(); break;
        case 60: *reinterpret_cast< int*>(_v) = _t->getEditLoginPadDigitNumber(); break;
        case 61: *reinterpret_cast< int*>(_v) = _t->getEditLabelColor(); break;
        case 62: *reinterpret_cast< int*>(_v) = _t->getEditLabelBorderColor(); break;
        case 63: *reinterpret_cast< int*>(_v) = _t->getEditLabelFontColor(); break;
        case 64: *reinterpret_cast< int*>(_v) = _t->getEditLabelFontSize(); break;
        case 65: *reinterpret_cast< bool*>(_v) = _t->getEditLabelFontBold(); break;
        case 66: *reinterpret_cast< bool*>(_v) = _t->getEditLabelFontUnderline(); break;
        case 67: *reinterpret_cast< int*>(_v) = _t->getEditLabelAlignment(); break;
        case 68: *reinterpret_cast< int*>(_v) = _t->getEditLabelThickness(); break;
        case 69: *reinterpret_cast< int*>(_v) = _t->getEditLabelAngle(); break;
        case 70: *reinterpret_cast< QString*>(_v) = _t->getEditLabelText(); break;
        case 71: *reinterpret_cast< bool*>(_v) = _t->getEditLabelTransparent(); break;
        case 72: *reinterpret_cast< int*>(_v) = _t->getEditLabelVisible(); break;
        case 73: *reinterpret_cast< int*>(_v) = _t->getEditScrollLabelColor(); break;
        case 74: *reinterpret_cast< int*>(_v) = _t->getEditScrollLabelBorderColor(); break;
        case 75: *reinterpret_cast< int*>(_v) = _t->getEditScrollLabelFontColor(); break;
        case 76: *reinterpret_cast< int*>(_v) = _t->getEditScrollLabelFontSize(); break;
        case 77: *reinterpret_cast< bool*>(_v) = _t->getEditScrollLabelFontBold(); break;
        case 78: *reinterpret_cast< bool*>(_v) = _t->getEditScrollLabelFontUnderline(); break;
        case 79: *reinterpret_cast< int*>(_v) = _t->getEditScrollLabelThickness(); break;
        case 80: *reinterpret_cast< QString*>(_v) = _t->getEditScrollLabelText(); break;
        case 81: *reinterpret_cast< bool*>(_v) = _t->getEditScrollLabelTransparent(); break;
        case 82: *reinterpret_cast< int*>(_v) = _t->getEditScrollLabelDirection(); break;
        case 83: *reinterpret_cast< int*>(_v) = _t->getEditScrollLabelSpeed(); break;
        case 84: *reinterpret_cast< int*>(_v) = _t->getEditScrollLabelVisible(); break;
        case 85: *reinterpret_cast< int*>(_v) = _t->getEditScrollLabelScrollFlag(); break;
        case 86: *reinterpret_cast< int*>(_v) = _t->getEditDigitalClockColor(); break;
        case 87: *reinterpret_cast< int*>(_v) = _t->getEditDigitalClockBorderColor(); break;
        case 88: *reinterpret_cast< int*>(_v) = _t->getEditDigitalClockFontColor(); break;
        case 89: *reinterpret_cast< int*>(_v) = _t->getEditDigitalClockFontBold(); break;
        case 90: *reinterpret_cast< int*>(_v) = _t->getEditDigitalClockFontSize(); break;
        case 91: *reinterpret_cast< int*>(_v) = _t->getEditDigitalClockTransparent(); break;
        case 92: *reinterpret_cast< int*>(_v) = _t->getEditLedColor(); break;
        case 93: *reinterpret_cast< int*>(_v) = _t->getEditPanelMax(); break;
        case 94: *reinterpret_cast< int*>(_v) = _t->getEditPanelMin(); break;
        case 95: *reinterpret_cast< int*>(_v) = _t->getEditPanelMajor(); break;
        case 96: *reinterpret_cast< int*>(_v) = _t->getEditPanelMinor(); break;
        case 97: *reinterpret_cast< int*>(_v) = _t->getEditPanelNeedleColor(); break;
        case 98: *reinterpret_cast< int*>(_v) = _t->getEditPanelDigitColor(); break;
        case 99: *reinterpret_cast< int*>(_v) = _t->getEditPanelBodyColor(); break;
        case 100: *reinterpret_cast< QString*>(_v) = _t->getEditImageName(); break;
        case 101: *reinterpret_cast< bool*>(_v) = _t->getEditImageGrayScale(); break;
        case 102: *reinterpret_cast< int*>(_v) = _t->getEditImageAngle(); break;
        case 103: *reinterpret_cast< int*>(_v) = _t->getEditImageVisible(); break;
        case 104: *reinterpret_cast< QString*>(_v) = _t->getEditRailImageName(); break;
        case 105: *reinterpret_cast< bool*>(_v) = _t->getEditRailGrayScale(); break;
        case 106: *reinterpret_cast< int*>(_v) = _t->getEditCircleFillColor(); break;
        case 107: *reinterpret_cast< int*>(_v) = _t->getEditCircleLineColor(); break;
        case 108: *reinterpret_cast< int*>(_v) = _t->getEditCircleLineThickness(); break;
        case 109: *reinterpret_cast< int*>(_v) = _t->getEditRectangleFillColor(); break;
        case 110: *reinterpret_cast< int*>(_v) = _t->getEditRectangleLineColor(); break;
        case 111: *reinterpret_cast< int*>(_v) = _t->getEditRectangleLineThickness(); break;
        case 112: *reinterpret_cast< int*>(_v) = _t->getEditRadioButtonID(); break;
        case 113: *reinterpret_cast< QString*>(_v) = _t->getEditRadioButtonText(); break;
        case 114: *reinterpret_cast< int*>(_v) = _t->getEditRadioButtonColor(); break;
        case 115: *reinterpret_cast< int*>(_v) = _t->getEditRadioButtonThickness(); break;
        case 116: *reinterpret_cast< int*>(_v) = _t->getEditRadioButtonBorderColor(); break;
        case 117: *reinterpret_cast< int*>(_v) = _t->getEditRadioButtonFontColor(); break;
        case 118: *reinterpret_cast< int*>(_v) = _t->getEditRadioButtonFontSize(); break;
        case 119: *reinterpret_cast< bool*>(_v) = _t->getEditRadioButtonFontBold(); break;
        case 120: *reinterpret_cast< bool*>(_v) = _t->getEditRadioButtonFontUnderline(); break;
        case 121: *reinterpret_cast< bool*>(_v) = _t->getEditRadioButtonTransparent(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        HMIForm *_t = static_cast<HMIForm *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setSelectedGUIOName(*reinterpret_cast< QString*>(_v)); break;
        case 1: _t->setGUIOName(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setGUIOType(*reinterpret_cast< QString*>(_v)); break;
        case 3: _t->setGUIOLayer(*reinterpret_cast< int*>(_v)); break;
        case 4: _t->setMakeGUIOCommand(*reinterpret_cast< bool*>(_v)); break;
        case 5: _t->setRemoveGUIOCommand(*reinterpret_cast< bool*>(_v)); break;
        case 6: _t->setEditPageName(*reinterpret_cast< QString*>(_v)); break;
        case 7: _t->setEditPageBackgroundImageName(*reinterpret_cast< QString*>(_v)); break;
        case 8: _t->setEditPageBackgroundColor(*reinterpret_cast< int*>(_v)); break;
        case 9: _t->setEditGUIOPropertyName(*reinterpret_cast< QString*>(_v)); break;
        case 10: _t->setEditGUIOPropertyLayer(*reinterpret_cast< int*>(_v)); break;
        case 11: _t->setEditGUIOPropertyX(*reinterpret_cast< int*>(_v)); break;
        case 12: _t->setEditGUIOPropertyY(*reinterpret_cast< int*>(_v)); break;
        case 13: _t->setEditGUIOPropertyWidth(*reinterpret_cast< int*>(_v)); break;
        case 14: _t->setEditGUIOPropertyHeight(*reinterpret_cast< int*>(_v)); break;
        case 15: _t->setEditPushButtonText(*reinterpret_cast< QString*>(_v)); break;
        case 16: _t->setEditPushButtonColor(*reinterpret_cast< int*>(_v)); break;
        case 17: _t->setEditPushButtonThickness(*reinterpret_cast< int*>(_v)); break;
        case 18: _t->setEditPushButtonBorderColor(*reinterpret_cast< int*>(_v)); break;
        case 19: _t->setEditPushButtonFontColor(*reinterpret_cast< int*>(_v)); break;
        case 20: _t->setEditPushButtonFontSize(*reinterpret_cast< int*>(_v)); break;
        case 21: _t->setEditPushButtonFontBold(*reinterpret_cast< bool*>(_v)); break;
        case 22: _t->setEditPushButtonFontUnderline(*reinterpret_cast< bool*>(_v)); break;
        case 23: _t->setEditDialColor(*reinterpret_cast< int*>(_v)); break;
        case 24: _t->setEditDialNeedleColor(*reinterpret_cast< int*>(_v)); break;
        case 25: _t->setEditDialFontColor(*reinterpret_cast< int*>(_v)); break;
        case 26: _t->setEditDialMin(*reinterpret_cast< int*>(_v)); break;
        case 27: _t->setEditDialMax(*reinterpret_cast< int*>(_v)); break;
        case 28: _t->setEditDialMinor(*reinterpret_cast< int*>(_v)); break;
        case 29: _t->setEditDialMajor(*reinterpret_cast< int*>(_v)); break;
        case 30: _t->setEditProgressBarColor(*reinterpret_cast< int*>(_v)); break;
        case 31: _t->setEditProgressBarOrient(*reinterpret_cast< int*>(_v)); break;
        case 32: _t->setEditProgressBarMin(*reinterpret_cast< int*>(_v)); break;
        case 33: _t->setEditProgressBarMax(*reinterpret_cast< int*>(_v)); break;
        case 34: _t->setEditProgressBarMinor(*reinterpret_cast< int*>(_v)); break;
        case 35: _t->setEditProgressBarMajor(*reinterpret_cast< int*>(_v)); break;
        case 36: _t->setEditSliderBarColor(*reinterpret_cast< int*>(_v)); break;
        case 37: _t->setEditSliderBarHandleColor(*reinterpret_cast< int*>(_v)); break;
        case 38: _t->setEditSliderBarOrient(*reinterpret_cast< int*>(_v)); break;
        case 39: _t->setEditSliderBarMin(*reinterpret_cast< int*>(_v)); break;
        case 40: _t->setEditSliderBarMax(*reinterpret_cast< int*>(_v)); break;
        case 41: _t->setEditSliderBarMinor(*reinterpret_cast< int*>(_v)); break;
        case 42: _t->setEditSliderBarMajor(*reinterpret_cast< int*>(_v)); break;
        case 43: _t->setEditNumPadNumberFontColor(*reinterpret_cast< int*>(_v)); break;
        case 44: _t->setEditNumPadNumberButtonColor(*reinterpret_cast< int*>(_v)); break;
        case 45: _t->setEditNumPadResetFontColor(*reinterpret_cast< int*>(_v)); break;
        case 46: _t->setEditNumPadResetButtonColor(*reinterpret_cast< int*>(_v)); break;
        case 47: _t->setEditNumPadOkFontColor(*reinterpret_cast< int*>(_v)); break;
        case 48: _t->setEditNumPadOkButtonColor(*reinterpret_cast< int*>(_v)); break;
        case 49: _t->setEditNumPadBorderColor(*reinterpret_cast< int*>(_v)); break;
        case 50: _t->setEditLoginPadPassword(*reinterpret_cast< QString*>(_v)); break;
        case 51: _t->setEditLoginPadNumberFontColor(*reinterpret_cast< int*>(_v)); break;
        case 52: _t->setEditLoginPadNumberButtonColor(*reinterpret_cast< int*>(_v)); break;
        case 53: _t->setEditLoginPadResetFontColor(*reinterpret_cast< int*>(_v)); break;
        case 54: _t->setEditLoginPadResetButtonColor(*reinterpret_cast< int*>(_v)); break;
        case 55: _t->setEditLoginPadLoginFontColor(*reinterpret_cast< int*>(_v)); break;
        case 56: _t->setEditLoginPadLoginButtonColor(*reinterpret_cast< int*>(_v)); break;
        case 57: _t->setEditLoginPadFuncFontColor(*reinterpret_cast< int*>(_v)); break;
        case 58: _t->setEditLoginPadFuncFontColor(*reinterpret_cast< int*>(_v)); break;
        case 59: _t->setEditLoginPadBorderColor(*reinterpret_cast< int*>(_v)); break;
        case 60: _t->setEditLoginPadDigitNumber(*reinterpret_cast< int*>(_v)); break;
        case 61: _t->setEditLabelColor(*reinterpret_cast< int*>(_v)); break;
        case 62: _t->setEditLabelBorderColor(*reinterpret_cast< int*>(_v)); break;
        case 63: _t->setEditLabelFontColor(*reinterpret_cast< int*>(_v)); break;
        case 64: _t->setEditLabelFontSize(*reinterpret_cast< int*>(_v)); break;
        case 65: _t->setEditLabelFontBold(*reinterpret_cast< bool*>(_v)); break;
        case 66: _t->setEditLabelFontUnderline(*reinterpret_cast< bool*>(_v)); break;
        case 67: _t->setEditLabelAlignment(*reinterpret_cast< int*>(_v)); break;
        case 68: _t->setEditLabelThickness(*reinterpret_cast< int*>(_v)); break;
        case 69: _t->setEditLabelAngle(*reinterpret_cast< int*>(_v)); break;
        case 70: _t->setEditLabelText(*reinterpret_cast< QString*>(_v)); break;
        case 71: _t->setEditLabelTransparent(*reinterpret_cast< bool*>(_v)); break;
        case 72: _t->setEditLabelVisible(*reinterpret_cast< int*>(_v)); break;
        case 73: _t->setEditScrollLabelColor(*reinterpret_cast< int*>(_v)); break;
        case 74: _t->setEditScrollLabelBorderColor(*reinterpret_cast< int*>(_v)); break;
        case 75: _t->setEditScrollLabelFontColor(*reinterpret_cast< int*>(_v)); break;
        case 76: _t->setEditScrollLabelFontSize(*reinterpret_cast< int*>(_v)); break;
        case 77: _t->setEditScrollLabelFontBold(*reinterpret_cast< bool*>(_v)); break;
        case 78: _t->setEditScrollLabelFontUnderline(*reinterpret_cast< bool*>(_v)); break;
        case 79: _t->setEditScrollLabelThickness(*reinterpret_cast< int*>(_v)); break;
        case 80: _t->setEditScrollLabelText(*reinterpret_cast< QString*>(_v)); break;
        case 81: _t->setEditScrollLabelTransparent(*reinterpret_cast< bool*>(_v)); break;
        case 82: _t->setEditScrollLabelDirection(*reinterpret_cast< int*>(_v)); break;
        case 83: _t->setEditScrollLabelSpeed(*reinterpret_cast< int*>(_v)); break;
        case 84: _t->setEditScrollLabelVisible(*reinterpret_cast< int*>(_v)); break;
        case 85: _t->setEditScrollLabelScrollFlag(*reinterpret_cast< int*>(_v)); break;
        case 86: _t->setEditDigitalClockColor(*reinterpret_cast< int*>(_v)); break;
        case 87: _t->setEditDigitalClockBorderColor(*reinterpret_cast< int*>(_v)); break;
        case 88: _t->setEditDigitalClockFontColor(*reinterpret_cast< int*>(_v)); break;
        case 89: _t->setEditDigitalClockFontBold(*reinterpret_cast< int*>(_v)); break;
        case 90: _t->setEditDigitalClockFontSize(*reinterpret_cast< int*>(_v)); break;
        case 91: _t->setEditDigitalClockTransparent(*reinterpret_cast< int*>(_v)); break;
        case 92: _t->setEditLedColor(*reinterpret_cast< int*>(_v)); break;
        case 93: _t->setEditPanelMax(*reinterpret_cast< int*>(_v)); break;
        case 94: _t->setEditPanelMin(*reinterpret_cast< int*>(_v)); break;
        case 95: _t->setEditPanelMajor(*reinterpret_cast< int*>(_v)); break;
        case 96: _t->setEditPanelMinor(*reinterpret_cast< int*>(_v)); break;
        case 97: _t->setEditPanelNeedleColor(*reinterpret_cast< int*>(_v)); break;
        case 98: _t->setEditPanelDigitColor(*reinterpret_cast< int*>(_v)); break;
        case 99: _t->setEditPanelBodyColor(*reinterpret_cast< int*>(_v)); break;
        case 100: _t->setEditImageName(*reinterpret_cast< QString*>(_v)); break;
        case 101: _t->setEditImageGrayScale(*reinterpret_cast< bool*>(_v)); break;
        case 102: _t->setEditImageAngle(*reinterpret_cast< int*>(_v)); break;
        case 103: _t->setEditImageVisible(*reinterpret_cast< int*>(_v)); break;
        case 104: _t->setEditRailImageName(*reinterpret_cast< QString*>(_v)); break;
        case 105: _t->setEditRailGrayScale(*reinterpret_cast< bool*>(_v)); break;
        case 106: _t->setEditCircleFillColor(*reinterpret_cast< int*>(_v)); break;
        case 107: _t->setEditCircleLineColor(*reinterpret_cast< int*>(_v)); break;
        case 108: _t->setEditCircleLineThickness(*reinterpret_cast< int*>(_v)); break;
        case 109: _t->setEditRectangleFillColor(*reinterpret_cast< int*>(_v)); break;
        case 110: _t->setEditRectangleLineColor(*reinterpret_cast< int*>(_v)); break;
        case 111: _t->setEditRectangleLineThickness(*reinterpret_cast< int*>(_v)); break;
        case 112: _t->setEditRadioButtonID(*reinterpret_cast< int*>(_v)); break;
        case 113: _t->setEditRadioButtonText(*reinterpret_cast< QString*>(_v)); break;
        case 114: _t->setEditRadioButtonColor(*reinterpret_cast< int*>(_v)); break;
        case 115: _t->setEditRadioButtonThickness(*reinterpret_cast< int*>(_v)); break;
        case 116: _t->setEditRadioButtonBorderColor(*reinterpret_cast< int*>(_v)); break;
        case 117: _t->setEditRadioButtonFontColor(*reinterpret_cast< int*>(_v)); break;
        case 118: _t->setEditRadioButtonFontSize(*reinterpret_cast< int*>(_v)); break;
        case 119: _t->setEditRadioButtonFontBold(*reinterpret_cast< bool*>(_v)); break;
        case 120: _t->setEditRadioButtonFontUnderline(*reinterpret_cast< bool*>(_v)); break;
        case 121: _t->setEditRadioButtonTransparent(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_a);
}

const QMetaObject HMIForm::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_HMIForm.data,
      qt_meta_data_HMIForm,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *HMIForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *HMIForm::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_HMIForm.stringdata0))
        return static_cast<void*>(const_cast< HMIForm*>(this));
    return QWidget::qt_metacast(_clname);
}

int HMIForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 122;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 122;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 122;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 122;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 122;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 122;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
